<?php

namespace App\Http\Controllers;

use App\Models\FamilyType;
use Illuminate\Http\Request;

class FamilyTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function FamilyType()
    {
       $data = FamilyType::get();
       return view('admin.tools.family-type', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(FamilyType $familyType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(FamilyType $familyType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FamilyType $familyType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(FamilyType $familyType)
    {
        //
    }
}
