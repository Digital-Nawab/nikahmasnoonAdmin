<?php

namespace App\Http\Controllers;

use App\Models\ProfileFor;
use Illuminate\Http\Request;

class ProfileForController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function ProfileFor()
    {
        $data = ProfileFor::get();
        return view('admin.tools.profile_for', compact('data'));
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProfileFor $profileFor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProfileFor $profileFor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ProfileFor $profileFor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProfileFor $profileFor)
    {
        //
    }
}
